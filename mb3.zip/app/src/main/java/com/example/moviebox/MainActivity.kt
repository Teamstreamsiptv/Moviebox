package com.example.moviebox

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import java.io.ByteArrayInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF101014))) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MovieBoxApp()
                }
            }
        }
    }
}

@Composable
fun MovieBoxApp(viewModel: MovieViewModel = viewModel()) {
    var showAddonDialog by remember { mutableStateOf(false) }

    if (showAddonDialog) {
        AddonSettingsDialog(
            currentUrl = viewModel.customAddonUrl,
            onSave = {
                viewModel.customAddonUrl = it
                showAddonDialog = false
            },
            onDismiss = { showAddonDialog = false }
        )
    }

    when {
        viewModel.activeStream != null -> {
            val stream = viewModel.activeStream!!
            if (stream.isWebEmbed) {
                WebEmbedPlayerScreen(
                    embedUrl = stream.streamUrl,
                    onBack = { viewModel.activeStream = null }
                )
            } else {
                NativeExoPlayerScreen(
                    streamUrl = stream.streamUrl,
                    onBack = { viewModel.activeStream = null }
                )
            }
        }
        viewModel.selectedMedia != null -> {
            MediaDetailScreen(
                item = viewModel.selectedMedia!!,
                streams = viewModel.availableStreams,
                isResolving = viewModel.isResolvingStreams,
                onBack = { viewModel.selectedMedia = null },
                onSelectStream = { viewModel.activeStream = it }
            )
        }
        else -> {
            CatalogHomeScreen(
                viewModel = viewModel,
                onOpenSettings = { showAddonDialog = true },
                onMediaClick = { viewModel.selectMediaAndResolveStreams(it) }
            )
        }
    }
}

@Composable
fun CatalogHomeScreen(
    viewModel: MovieViewModel,
    onOpenSettings: () -> Unit,
    onMediaClick: (MediaCatalogItem) -> Unit
) {
    val categories = listOf("Movies", "TV Series", "Free Direct MP4")

    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MovieBox Pro",
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFE50914)
            )
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Stream Sources", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = viewModel.searchQuery,
            onValueChange = viewModel::onSearchQueryChanged,
            placeholder = { Text("Search any movie or series (Full IMDb Catalog)...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (viewModel.searchQuery.isBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { category ->
                    val selected = viewModel.selectedCategory == category
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.selectedCategory = category },
                        label = { Text(category) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        val displayedItems = when {
            viewModel.searchQuery.isNotBlank() -> viewModel.searchResults
            viewModel.selectedCategory == "Movies" -> viewModel.topMovies
            viewModel.selectedCategory == "TV Series" -> viewModel.topSeries
            else -> viewModel.freeDirectMovies
        }

        if (viewModel.isLoading && displayedItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFE50914))
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(displayedItems) { item ->
                    CatalogCard(item = item, onClick = { onMediaClick(item) })
                }
                if (viewModel.searchQuery.isBlank() && viewModel.selectedCategory != "Free Direct MP4") {
                    item {
                        OutlinedButton(
                            onClick = { viewModel.loadMoreCatalog() },
                            modifier = Modifier.fillMaxWidth().height(175.dp)
                        ) {
                            Text("Load More
Catalog")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CatalogCard(item: MediaCatalogItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Box {
            AsyncImage(
                model = item.posterUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .height(175.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF222228))
            )
            if (item.rating.isNotBlank() && item.rating != "N/A") {
                Surface(
                    color = Color.Black.copy(alpha = 0.75f),
                    shape = RoundedCornerShape(bottomEnd = 8.dp, topStart = 8.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "★ ${item.rating}",
                        color = Color(0xFFFFD700),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = item.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
        )
        Text(
            text = item.year,
            maxLines = 1,
            fontSize = 11.sp,
            color = Color.Gray
        )
    }
}

@Composable
fun MediaDetailScreen(
    item: MediaCatalogItem,
    streams: List<ResolvedStream>,
    isResolving: Boolean,
    onBack: () -> Unit,
    onSelectStream: (ResolvedStream) -> Unit
) {
    BackHandler { onBack() }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Box(modifier = Modifier.height(250.dp).fillMaxWidth()) {
                AsyncImage(
                    model = item.backdropUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().background(Color.DarkGray)
                )
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(item.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(item.rating, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(item.year, color = Color.Gray)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("ID: ${item.id}", color = Color.Gray, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(item.overview, color = Color.LightGray, lineHeight = 20.sp, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(20.dp))

                Text("Available Streaming Sources", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))

                if (isResolving) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFFE50914))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Scraping stream providers for ${item.id}...", color = Color.Gray)
                    }
                }
            }
        }

        items(streams) { stream ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { onSelectStream(stream) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stream.providerName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(stream.qualityLabel, color = Color(0xFF4CAF50), fontSize = 12.sp)
                    }
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color(0xFFE50914))
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun NativeExoPlayerScreen(streamUrl: String, onBack: () -> Unit) {
    val context = LocalContext.current
    BackHandler { onBack() }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebEmbedPlayerScreen(embedUrl: String, onBack: () -> Unit) {
    BackHandler { onBack() }

    // Ad-blocking domains filter so multi-server embeds play cleanly without popups
    val blockedHosts = remember {
        listOf("doubleclick.net", "googlesyndication.com", "popads.net", "adnxs.com", "exoclick.com", "propellerads.com")
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.supportMultipleWindows(false) // Blocks popup windows

                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val reqUrl = request?.url?.toString() ?: return false
                            // Keep navigation inside the video embed player; block external redirect ads
                            return !(reqUrl.contains("vidsrc") || reqUrl.contains("embed") || reqUrl.contains("multiembed") || reqUrl.contains("2embed"))
                        }

                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val host = request?.url?.host ?: return super.shouldInterceptRequest(view, request)
                            if (blockedHosts.any { host.contains(it) }) {
                                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".toByteArray()))
                            }
                            return super.shouldInterceptRequest(view, request)
                        }
                    }
                    loadUrl(embedUrl)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        IconButton(
            onClick = onBack,
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopStart)
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Close Player", tint = Color.White)
        }
    }
}

@Composable
fun AddonSettingsDialog(currentUrl: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(currentUrl) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configure Stream Provider") },
        text = {
            Column {
                Text(
                    "Paste any Stremio-compatible HTTP stream addon base URL (or keep the default). The app also includes 4 built-in multi-CDN resolvers.",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text("https://...") }
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(text) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
