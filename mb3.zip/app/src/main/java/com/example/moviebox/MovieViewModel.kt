package com.example.moviebox

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MovieViewModel : ViewModel() {
    private val api = CatalogAndStreamApi.create()

    var topMovies by mutableStateOf<List<MediaCatalogItem>>(emptyList())
    var topSeries by mutableStateOf<List<MediaCatalogItem>>(emptyList())
    var freeDirectMovies by mutableStateOf<List<MediaCatalogItem>>(emptyList())
    var searchResults by mutableStateOf<List<MediaCatalogItem>>(emptyList())

    var searchQuery by mutableStateOf("")
    var selectedCategory by mutableStateOf("Movies") // "Movies", "TV Series", "Free Direct MP4"
    var isLoading by mutableStateOf(false)
    var isResolvingStreams by mutableStateOf(false)

    var selectedMedia by mutableStateOf<MediaCatalogItem?>(null)
    var availableStreams by mutableStateOf<List<ResolvedStream>>(emptyList())
    var activeStream by mutableStateOf<ResolvedStream?>(null)

    // User-configurable Stream Providers (supports Stremio Addon base URLs & multi-server Web Embeds)
    var customAddonUrl by mutableStateOf("https://webstreamr.hayd.uk")

    private var searchJob: Job? = null
    private var currentSkip = 0

    init {
        loadFullCatalog()
    }

    fun loadFullCatalog() {
        viewModelScope.launch {
            isLoading = true
            try {
                // 1. Load Popular Movies (IMDb / Cinemeta Full Catalog - No Key Needed)
                val movieRes = api.getCatalog("movie", "top")
                topMovies = movieRes.metas?.map { it.toCatalogItem("movie") } ?: emptyList()

                // 2. Load Popular TV Series
                val seriesRes = api.getCatalog("series", "top")
                topSeries = seriesRes.metas?.map { it.toCatalogItem("series") } ?: emptyList()

                // 3. Load Direct MP4 Feature Films from Archive.org
                val archiveRes = api.getFreeStreamableArchiveMovies()
                freeDirectMovies = archiveRes.response?.docs?.map { doc ->
                    val id = doc.identifier
                    MediaCatalogItem(
                        id = id,
                        title = doc.title ?: id,
                        overview = doc.description?.toString() ?: "Classic Feature Film with direct MP4 playback.",
                        posterUrl = "https://archive.org/services/img/$id",
                        backdropUrl = "https://archive.org/services/img/$id",
                        rating = "Direct MP4",
                        year = doc.year?.toString() ?: "Classic",
                        mediaType = "archive"
                    )
                } ?: emptyList()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }

    fun loadMoreCatalog() {
        viewModelScope.launch {
            try {
                currentSkip += 100
                val type = if (selectedCategory == "TV Series") "series" else "movie"
                val more = api.getCatalogPage(type, currentSkip).metas?.map { it.toCatalogItem(type) } ?: emptyList()
                if (type == "movie") {
                    topMovies = topMovies + more
                } else {
                    topSeries = topSeries + more
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        searchQuery = query
        searchJob?.cancel()
        if (query.isBlank()) {
            searchResults = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(400)
            try {
                val movies = api.searchCatalog("movie", query).metas?.map { it.toCatalogItem("movie") } ?: emptyList()
                val series = api.searchCatalog("series", query).metas?.map { it.toCatalogItem("series") } ?: emptyList()
                searchResults = movies + series
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun selectMediaAndResolveStreams(item: MediaCatalogItem) {
        selectedMedia = item
        availableStreams = emptyList()
        isResolvingStreams = true

        viewModelScope.launch {
            val resolved = mutableListOf<ResolvedStream>()

            try {
                if (item.mediaType == "archive") {
                    // Fetch exact MP4 file from Archive.org metadata
                    val meta = api.getArchiveMovieFiles(item.id)
                    val mp4Files = meta.files?.filter {
                        it.name?.endsWith(".mp4", ignoreCase = true) == true
                    } ?: emptyList()

                    for (file in mp4Files) {
                        val fileName = file.name ?: continue
                        resolved.add(
                            ResolvedStream(
                                providerName = "Archive Direct CDN",
                                qualityLabel = file.format ?: "MP4 Direct",
                                streamUrl = "https://archive.org/download/${item.id}/$fileName",
                                isWebEmbed = false
                            )
                        )
                    }
                } else {
                    // 1. Query Configured Stremio HTTP Stream Addon (e.g. WebStreamr / Custom Addon)
                    val cleanBase = customAddonUrl.trimEnd('/').removeSuffix("/manifest.json")
                    val streamEndpoint = "$cleanBase/stream/${item.mediaType}/${item.id}.json"
                    try {
                        val addonRes = api.getAddonStreams(streamEndpoint)
                        addonRes.streams?.forEach { s ->
                            if (!s.url.isNullOrBlank()) {
                                resolved.add(
                                    ResolvedStream(
                                        providerName = s.name ?: "Addon Direct Stream",
                                        qualityLabel = s.title ?: "HTTP Stream",
                                        streamUrl = s.url,
                                        isWebEmbed = false
                                    )
                                )
                            }
                        }
                    } catch (_: Exception) {
                        // Addon didn't have direct HTTP link, fallback to multi-server embeds
                    }

                    // 2. Multi-Server Embed Resolvers by IMDb ID (Works for all Movies & Series in Catalog)
                    val mediaPath = if (item.mediaType == "series") "tv" else "movie"
                    resolved.add(
                        ResolvedStream(
                            providerName = "Server 1: VidSrc Pro (Auto-Resolver)",
                            qualityLabel = "1080p Multi-CDN Embed",
                            streamUrl = "https://vidsrc.xyz/embed/$mediaPath/${item.id}",
                            isWebEmbed = true
                        )
                    )
                    resolved.add(
                        ResolvedStream(
                            providerName = "Server 2: VidSrc.to (Fast Cloud)",
                            qualityLabel = "1080p / 720p Auto",
                            streamUrl = "https://vidsrc.to/embed/$mediaPath/${item.id}",
                            isWebEmbed = true
                        )
                    )
                    resolved.add(
                        ResolvedStream(
                            providerName = "Server 3: SuperEmbed (Multi-Host)",
                            qualityLabel = "HD Backup Stream",
                            streamUrl = "https://multiembed.mov/?video_id=${item.id}",
                            isWebEmbed = true
                        )
                    )
                    resolved.add(
                        ResolvedStream(
                            providerName = "Server 4: 2Embed Server",
                            qualityLabel = "HD Mirror",
                            streamUrl = "https://www.2embed.cc/embed/${item.id}",
                            isWebEmbed = true
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Always include a guaranteed native ExoPlayer test stream at the bottom
            resolved.add(
                ResolvedStream(
                    providerName = "ExoPlayer Native HLS Test",
                    qualityLabel = "1080p Adaptive HLS (.m3u8)",
                    streamUrl = "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8",
                    isWebEmbed = false
                )
            )

            availableStreams = resolved
            isResolvingStreams = false
        }
    }

    private fun MetaItem.toCatalogItem(type: String): MediaCatalogItem {
        return MediaCatalogItem(
            id = this.id,
            title = this.name,
            overview = this.description ?: "Full synopsis available via IMDb (${this.id}). Select a streaming server below to watch.",
            posterUrl = this.poster ?: "https://images.metahub.space/poster/medium/${this.id}/img",
            backdropUrl = this.background ?: "https://images.metahub.space/background/medium/${this.id}/img",
            rating = this.imdbRating ?: "N/A",
            year = this.releaseInfo ?: "",
            mediaType = type
        )
    }
}
