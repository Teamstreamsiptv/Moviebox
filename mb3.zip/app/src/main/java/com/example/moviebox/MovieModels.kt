package com.example.moviebox

import com.google.gson.annotations.SerializedName

// Cinemeta / Stremio Full Catalog Models (No API Key Needed)
data class CinemetaCatalogResponse(
    val metas: List<MetaItem>?
)

data class CinemetaMetaResponse(
    val meta: MetaItem?
)

data class MetaItem(
    val id: String, // IMDb ID (e.g., "tt1234567")
    val type: String?,
    val name: String,
    val poster: String?,
    val background: String?,
    val description: String?,
    val releaseInfo: String?,
    val imdbRating: String?,
    val genres: List<String>?
)

// Stream Resolver Models (Stremio Addon Protocol + Internet Archive Direct MP4s)
data class StreamResponse(
    val streams: List<StreamSource>?
)

data class StreamSource(
    val name: String?,
    val title: String?,
    val url: String?,
    val externalUrl: String?,
    val infoHash: String?
)

// Archive.org Search Models for Direct MP4 Public Domain Feature Films
data class ArchiveSearchResponse(
    val response: ArchiveDocs?
)

data class ArchiveDocs(
    val docs: List<ArchiveDoc>?
)

data class ArchiveDoc(
    val identifier: String,
    val title: String?,
    val description: Any?,
    val year: Any?
)

data class ArchiveMetadataResponse(
    val files: List<ArchiveFile>?
)

data class ArchiveFile(
    val name: String?,
    val format: String?
)

// Unified UI Model
data class MediaCatalogItem(
    val id: String,
    val title: String,
    val overview: String,
    val posterUrl: String,
    val backdropUrl: String,
    val rating: String,
    val year: String,
    val mediaType: String = "movie", // "movie", "series", "archive"
    val directStreamUrl: String? = null
)

data class ResolvedStream(
    val providerName: String,
    val qualityLabel: String,
    val streamUrl: String,
    val isWebEmbed: Boolean = false
)
