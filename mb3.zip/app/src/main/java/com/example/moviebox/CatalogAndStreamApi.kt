package com.example.moviebox

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url

interface CatalogAndStreamApi {
    // 1. Keyless Full Movie & TV Catalog via Cinemeta (Official Stremio Catalog)
    @GET("https://v3-cinemeta.strem.io/catalog/{type}/{catalogId}.json")
    suspend fun getCatalog(
        @Path("type") type: String, // "movie" or "series"
        @Path("catalogId") catalogId: String // "top", "year", "imdbRating"
    ): CinemetaCatalogResponse

    @GET("https://v3-cinemeta.strem.io/catalog/{type}/top/skip={skip}.json")
    suspend fun getCatalogPage(
        @Path("type") type: String,
        @Path("skip") skip: Int
    ): CinemetaCatalogResponse

    @GET("https://v3-cinemeta.strem.io/catalog/{type}/top/search={query}.json")
    suspend fun searchCatalog(
        @Path("type") type: String,
        @Path("query") query: String
    ): CinemetaCatalogResponse

    // 2. Dynamic Stremio-compatible Stream Addon Endpoint
    // Queries any configured addon base URL: {baseUrl}/stream/{type}/{imdbId}.json
    @GET
    suspend fun getAddonStreams(@Url fullStreamEndpointUrl: String): StreamResponse

    // 3. Internet Archive Feature Films Catalog (100% Free Direct MP4 Streams)
    @GET("https://archive.org/advancedsearch.php?q=collection:(feature_films)+AND+mediatype:(movies)&fl[]=identifier,title,description,year&sort[]=downloads+desc&rows=40&page=1&output=json")
    suspend fun getFreeStreamableArchiveMovies(): ArchiveSearchResponse

    @GET("https://archive.org/metadata/{identifier}")
    suspend fun getArchiveMovieFiles(@Path("identifier") identifier: String): ArchiveMetadataResponse

    companion object {
        fun create(): CatalogAndStreamApi {
            return Retrofit.Builder()
                .baseUrl("https://v3-cinemeta.strem.io/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(CatalogAndStreamApi::class.java)
        }
    }
}
