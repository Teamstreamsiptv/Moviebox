package com.example.moviebox

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MovieViewModel : ViewModel() {
    private val api = TmdbApi.create()

    private val demoMovies = listOf(
        Movie(1, "Tears of Steel (Open Stream)", "In an apocalyptic future, a group of soldiers and scientists gather at the Oude Kerk in Amsterdam to stage a crucial event from the past.", "/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg", "/bOGkgRGdhrBYJSLpXaxhXVstddV.jpg", 8.2, "2012-09-26"),
        Movie(2, "Big Buck Bunny", "Follow a day in the life of Big Buck Bunny when he meets three bullying rodents.", "/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg", "/fCayJrkfRaCRCTh8GqN30f8oyQF.jpg", 7.5, "2008-05-30"),
        Movie(3, "Sintel", "A lonely young woman, Sintel, helps and befriends a dragon, whom she calls Scales.", "/qJ2tW6WMUDux911r6m7haRef0WH.jpg", "/hkBaDkMWbLaf8B1lsWsKX7Ew3Xq.jpg", 8.5, "2010-09-27")
    )

    var trendingMovies by mutableStateOf<List<Movie>>(demoMovies)
    var popularMovies by mutableStateOf<List<Movie>>(demoMovies)
    var searchResults by mutableStateOf<List<Movie>>(emptyList())
    var searchQuery by mutableStateOf("")
    var isLoading by mutableStateOf(false)
    var selectedMovie by mutableStateOf<Movie?>(null)

    private var searchJob: Job? = null

    init {
        loadHomeContent()
    }

    private fun loadHomeContent() {
        if (TmdbApi.API_KEY == "YOUR_TMDB_API_KEY") return
        viewModelScope.launch {
            isLoading = true
            try {
                trendingMovies = api.getTrendingMovies().results
                popularMovies = api.getPopularMovies().results
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        searchQuery = query
        searchJob?.cancel()
        if (query.isBlank()) {
            searchResults = emptyList()
            return
        }
        if (TmdbApi.API_KEY == "YOUR_TMDB_API_KEY") {
            searchResults = demoMovies.filter { it.title.contains(query, ignoreCase = true) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(400)
            try {
                searchResults = api.searchMovies(query).results
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
