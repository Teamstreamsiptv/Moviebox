package com.example.moviebox

import com.google.gson.annotations.SerializedName

data class MovieResponse(
    val results: List<Movie>
)

data class Movie(
    val id: Int,
    val title: String,
    val overview: String,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val rating: Double,
    @SerializedName("release_date") val releaseDate: String?
) {
    val fullPosterUrl: String
        get() = "https://image.tmdb.org/t/p/w500$posterPath"
    
    val fullBackdropUrl: String
        get() = "https://image.tmdb.org/t/p/w780$backdropPath"
}
